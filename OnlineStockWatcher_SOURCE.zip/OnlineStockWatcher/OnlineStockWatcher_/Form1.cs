﻿using Microsoft.Ajax.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Helpers;
using System.Windows.Forms;

namespace OnlineStockWatcher_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string link_A = "https://api.twelvedata.com/time_series?symbol=";
        string Link_B = "&interval=";
        string Link_C = "&apikey=";
        string Link_D = "&source=docs";

        string Key = "74530d4ea3ee4ab5ba3541b7253d7b15";

        // Main Functions

        void searchStock(string symbol, string interval, string key)
        {
            string Link = link_A + symbol + Link_B + interval + Link_C + key + Link_D;

            //output.Text = Link; Passed

            string result = "";
            using (WebClient client = new WebClient()) result = client.DownloadString(Link);
            output.Text = result;

            Root resultJSON = JsonConvert.DeserializeObject<Root>(result);
            Value valuesJSON = JsonConvert.DeserializeObject<Value>(result);
            Meta metaJSON = JsonConvert.DeserializeObject<Meta>(result);

            if (resultJSON.status == "ok")
            {
                var n = resultJSON.values[0];
                var b = resultJSON.values[1];

                float no = float.Parse(n.open);
                float bo = float.Parse(b.open);

                float nc = float.Parse(n.close);
                float bc = float.Parse(b.close);

                float hi = float.Parse(n.high);
                float lo = float.Parse(n.low);

                openN.Text = no.ToString() + " | NOW: " + n.datetime;
                openL.Text = bo.ToString() + " | BEFORE: " + b.datetime;
                if (no > bo) { openN.ForeColor = System.Drawing.Color.Green; openL.ForeColor = System.Drawing.Color.Red; }

                closeN.Text = nc.ToString() + " | NOW: " + n.datetime;
                closeL.Text = bc.ToString() + " | BEFORE: " + b.datetime;
                if (nc > bc) { closeN.ForeColor = System.Drawing.Color.Green; closeL.ForeColor = System.Drawing.Color.Red; }

                h.Text = hi.ToString();
                l.Text = lo.ToString();
                label5.Text = "high / low  | " + n.datetime;

                float newNumber = nc - bc;
                newNumber = (newNumber / bc) * 100;
                if (newNumber < 0) { pp.ForeColor = System.Drawing.Color.Red; }
                pp.Text = $"Stock gain/lost: {Math.Abs(newNumber)}% [ {Math.Abs(nc - bc)} ]";

                dates.Text = b.datetime + " > " + n.datetime;
            }
            else { output.Text = "FAILED TO FETCH DATA"; }
        }

        // List Classes | Use this code: [ Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); ]

        public class Meta
        {
            public string symbol { get; set; }
            public string interval { get; set; }
            public string currency_base { get; set; }
            public string currency_quote { get; set; }
            public string exchange { get; set; }
            public string type { get; set; }
        }

        public class Value
        {
            public string datetime { get; set; }
            public string open { get; set; }
            public string high { get; set; }
            public string low { get; set; }
            public string close { get; set; }
        }

        public class Root
        {
            public Meta meta { get; set; }
            public List<Value> values { get; set; }
            public string status { get; set; }
        }

        // Main Code

        private void pv_Click(object sender, EventArgs e)
        {
            string symbol = symbolText.Text;
            output.Text = "Loading data, may take a while...";

            string intv = "";
            if (m1.Checked) intv = "1min";
            if (m5.Checked) intv = "5min";
            if (m15.Checked) intv = "15min";
            if (m30.Checked) intv = "30min";
            if (m45.Checked) intv = "45min";
            if (h1.Checked) intv = "1h";
            if (h2.Checked) intv = "2h";
            if (h4.Checked) intv = "4h";
            if (h8.Checked) intv = "8h";
            if (d1.Checked) intv = "1day";
            if (w1.Checked) intv = "1week";
            if (mo1.Checked) intv = "1month";

            searchStock(symbol, intv, Key);
        }
    }
}
