﻿
namespace OnlineStockWatcher_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.mo1 = new System.Windows.Forms.RadioButton();
            this.w1 = new System.Windows.Forms.RadioButton();
            this.d1 = new System.Windows.Forms.RadioButton();
            this.h8 = new System.Windows.Forms.RadioButton();
            this.h2 = new System.Windows.Forms.RadioButton();
            this.m45 = new System.Windows.Forms.RadioButton();
            this.m30 = new System.Windows.Forms.RadioButton();
            this.h1 = new System.Windows.Forms.RadioButton();
            this.h4 = new System.Windows.Forms.RadioButton();
            this.m15 = new System.Windows.Forms.RadioButton();
            this.m5 = new System.Windows.Forms.RadioButton();
            this.m1 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.los = new System.Windows.Forms.ListBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.output = new System.Windows.Forms.TextBox();
            this.symbolText = new System.Windows.Forms.TextBox();
            this.atwl = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.openN = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.closeN = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.h = new System.Windows.Forms.Label();
            this.l = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dates = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.closeL = new System.Windows.Forms.Label();
            this.openL = new System.Windows.Forms.Label();
            this.pv = new System.Windows.Forms.Button();
            this.pp = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(441, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(170, 319);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stock Settings";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.mo1);
            this.groupBox2.Controls.Add(this.w1);
            this.groupBox2.Controls.Add(this.d1);
            this.groupBox2.Controls.Add(this.h8);
            this.groupBox2.Controls.Add(this.h2);
            this.groupBox2.Controls.Add(this.m45);
            this.groupBox2.Controls.Add(this.m30);
            this.groupBox2.Controls.Add(this.h1);
            this.groupBox2.Controls.Add(this.h4);
            this.groupBox2.Controls.Add(this.m15);
            this.groupBox2.Controls.Add(this.m5);
            this.groupBox2.Controls.Add(this.m1);
            this.groupBox2.Location = new System.Drawing.Point(7, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(157, 294);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Interval";
            // 
            // mo1
            // 
            this.mo1.AutoSize = true;
            this.mo1.Location = new System.Drawing.Point(7, 273);
            this.mo1.Name = "mo1";
            this.mo1.Size = new System.Drawing.Size(63, 17);
            this.mo1.TabIndex = 12;
            this.mo1.TabStop = true;
            this.mo1.Text = "1 month";
            this.mo1.UseVisualStyleBackColor = true;
            // 
            // w1
            // 
            this.w1.AutoSize = true;
            this.w1.Location = new System.Drawing.Point(7, 250);
            this.w1.Name = "w1";
            this.w1.Size = new System.Drawing.Size(60, 17);
            this.w1.TabIndex = 11;
            this.w1.TabStop = true;
            this.w1.Text = "1 week";
            this.w1.UseVisualStyleBackColor = true;
            // 
            // d1
            // 
            this.d1.AutoSize = true;
            this.d1.Checked = true;
            this.d1.Location = new System.Drawing.Point(7, 227);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(51, 17);
            this.d1.TabIndex = 10;
            this.d1.TabStop = true;
            this.d1.Text = "1 day";
            this.d1.UseVisualStyleBackColor = true;
            // 
            // h8
            // 
            this.h8.AutoSize = true;
            this.h8.Location = new System.Drawing.Point(7, 204);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(60, 17);
            this.h8.TabIndex = 9;
            this.h8.TabStop = true;
            this.h8.Text = "8 hours";
            this.h8.UseVisualStyleBackColor = true;
            // 
            // h2
            // 
            this.h2.AutoSize = true;
            this.h2.Location = new System.Drawing.Point(7, 158);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(60, 17);
            this.h2.TabIndex = 8;
            this.h2.TabStop = true;
            this.h2.Text = "2 hours";
            this.h2.UseVisualStyleBackColor = true;
            // 
            // m45
            // 
            this.m45.AutoSize = true;
            this.m45.Location = new System.Drawing.Point(7, 112);
            this.m45.Name = "m45";
            this.m45.Size = new System.Drawing.Size(56, 17);
            this.m45.TabIndex = 7;
            this.m45.TabStop = true;
            this.m45.Text = "45 min";
            this.m45.UseVisualStyleBackColor = true;
            // 
            // m30
            // 
            this.m30.AutoSize = true;
            this.m30.Location = new System.Drawing.Point(7, 89);
            this.m30.Name = "m30";
            this.m30.Size = new System.Drawing.Size(56, 17);
            this.m30.TabIndex = 6;
            this.m30.TabStop = true;
            this.m30.Text = "30 min";
            this.m30.UseVisualStyleBackColor = true;
            // 
            // h1
            // 
            this.h1.AutoSize = true;
            this.h1.Location = new System.Drawing.Point(7, 135);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(55, 17);
            this.h1.TabIndex = 5;
            this.h1.TabStop = true;
            this.h1.Text = "1 hour";
            this.h1.UseVisualStyleBackColor = true;
            // 
            // h4
            // 
            this.h4.AutoSize = true;
            this.h4.Location = new System.Drawing.Point(7, 181);
            this.h4.Name = "h4";
            this.h4.Size = new System.Drawing.Size(60, 17);
            this.h4.TabIndex = 4;
            this.h4.TabStop = true;
            this.h4.Text = "4 hours";
            this.h4.UseVisualStyleBackColor = true;
            // 
            // m15
            // 
            this.m15.AutoSize = true;
            this.m15.Location = new System.Drawing.Point(7, 66);
            this.m15.Name = "m15";
            this.m15.Size = new System.Drawing.Size(56, 17);
            this.m15.TabIndex = 3;
            this.m15.TabStop = true;
            this.m15.Text = "15 min";
            this.m15.UseVisualStyleBackColor = true;
            // 
            // m5
            // 
            this.m5.AutoSize = true;
            this.m5.Location = new System.Drawing.Point(7, 43);
            this.m5.Name = "m5";
            this.m5.Size = new System.Drawing.Size(50, 17);
            this.m5.TabIndex = 1;
            this.m5.TabStop = true;
            this.m5.Text = "5 min";
            this.m5.UseVisualStyleBackColor = true;
            // 
            // m1
            // 
            this.m1.AutoSize = true;
            this.m1.Location = new System.Drawing.Point(7, 20);
            this.m1.Name = "m1";
            this.m1.Size = new System.Drawing.Size(50, 17);
            this.m1.TabIndex = 0;
            this.m1.TabStop = true;
            this.m1.Text = "1 min";
            this.m1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pp);
            this.groupBox3.Controls.Add(this.openL);
            this.groupBox3.Controls.Add(this.closeL);
            this.groupBox3.Controls.Add(this.dates);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.l);
            this.groupBox3.Controls.Add(this.h);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.closeN);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.openN);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(13, 190);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(422, 141);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Results";
            // 
            // los
            // 
            this.los.FormattingEnabled = true;
            this.los.Items.AddRange(new object[] {
            " ( Comming soon! )"});
            this.los.Location = new System.Drawing.Point(6, 20);
            this.los.Name = "los";
            this.los.Size = new System.Drawing.Size(239, 95);
            this.los.TabIndex = 2;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pv);
            this.groupBox4.Controls.Add(this.atwl);
            this.groupBox4.Controls.Add(this.symbolText);
            this.groupBox4.Controls.Add(this.output);
            this.groupBox4.Controls.Add(this.los);
            this.groupBox4.Location = new System.Drawing.Point(13, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(422, 172);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Stocks";
            // 
            // output
            // 
            this.output.Location = new System.Drawing.Point(251, 20);
            this.output.Multiline = true;
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(165, 146);
            this.output.TabIndex = 3;
            // 
            // symbolText
            // 
            this.symbolText.Location = new System.Drawing.Point(7, 121);
            this.symbolText.Name = "symbolText";
            this.symbolText.Size = new System.Drawing.Size(238, 20);
            this.symbolText.TabIndex = 4;
            // 
            // atwl
            // 
            this.atwl.Location = new System.Drawing.Point(6, 143);
            this.atwl.Name = "atwl";
            this.atwl.Size = new System.Drawing.Size(113, 23);
            this.atwl.TabIndex = 5;
            this.atwl.Text = "Add to watch list";
            this.atwl.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Open";
            // 
            // openN
            // 
            this.openN.AutoSize = true;
            this.openN.ForeColor = System.Drawing.Color.Red;
            this.openN.Location = new System.Drawing.Point(7, 33);
            this.openN.Name = "openN";
            this.openN.Size = new System.Drawing.Size(28, 13);
            this.openN.TabIndex = 1;
            this.openN.Text = "0.00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Current Price";
            // 
            // closeN
            // 
            this.closeN.AutoSize = true;
            this.closeN.ForeColor = System.Drawing.Color.Red;
            this.closeN.Location = new System.Drawing.Point(7, 86);
            this.closeN.Name = "closeN";
            this.closeN.Size = new System.Drawing.Size(28, 13);
            this.closeN.TabIndex = 3;
            this.closeN.Text = "0.00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(216, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "high / low  | 0000-00-00";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // h
            // 
            this.h.AutoSize = true;
            this.h.ForeColor = System.Drawing.Color.Green;
            this.h.Location = new System.Drawing.Point(216, 33);
            this.h.Name = "h";
            this.h.Size = new System.Drawing.Size(28, 13);
            this.h.TabIndex = 5;
            this.h.Text = "0.00";
            // 
            // l
            // 
            this.l.AutoSize = true;
            this.l.ForeColor = System.Drawing.Color.Red;
            this.l.Location = new System.Drawing.Point(216, 46);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(28, 13);
            this.l.TabIndex = 6;
            this.l.Text = "0.00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(216, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Date Time";
            // 
            // dates
            // 
            this.dates.AutoSize = true;
            this.dates.Location = new System.Drawing.Point(216, 86);
            this.dates.Name = "dates";
            this.dates.Size = new System.Drawing.Size(127, 13);
            this.dates.TabIndex = 8;
            this.dates.Text = "0000-00-00 > 0000-00-00";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Silver;
            this.label10.Location = new System.Drawing.Point(476, 334);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(135, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Powered by twelvedata api";
            // 
            // closeL
            // 
            this.closeL.AutoSize = true;
            this.closeL.ForeColor = System.Drawing.Color.Green;
            this.closeL.Location = new System.Drawing.Point(7, 99);
            this.closeL.Name = "closeL";
            this.closeL.Size = new System.Drawing.Size(28, 13);
            this.closeL.TabIndex = 9;
            this.closeL.Text = "0.00";
            // 
            // openL
            // 
            this.openL.AutoSize = true;
            this.openL.ForeColor = System.Drawing.Color.Green;
            this.openL.Location = new System.Drawing.Point(7, 46);
            this.openL.Name = "openL";
            this.openL.Size = new System.Drawing.Size(28, 13);
            this.openL.TabIndex = 10;
            this.openL.Text = "0.00";
            // 
            // pv
            // 
            this.pv.Location = new System.Drawing.Point(132, 143);
            this.pv.Name = "pv";
            this.pv.Size = new System.Drawing.Size(113, 23);
            this.pv.TabIndex = 6;
            this.pv.Text = "Preview";
            this.pv.UseVisualStyleBackColor = true;
            this.pv.Click += new System.EventHandler(this.pv_Click);
            // 
            // pp
            // 
            this.pp.AutoSize = true;
            this.pp.ForeColor = System.Drawing.Color.Green;
            this.pp.Location = new System.Drawing.Point(6, 123);
            this.pp.Name = "pp";
            this.pp.Size = new System.Drawing.Size(114, 13);
            this.pp.TabIndex = 11;
            this.pp.Text = "Stock gain/lost: 0.00%";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(623, 355);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Stonks";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton m5;
        private System.Windows.Forms.RadioButton m1;
        private System.Windows.Forms.RadioButton h2;
        private System.Windows.Forms.RadioButton m45;
        private System.Windows.Forms.RadioButton m30;
        private System.Windows.Forms.RadioButton h1;
        private System.Windows.Forms.RadioButton h4;
        private System.Windows.Forms.RadioButton m15;
        private System.Windows.Forms.RadioButton mo1;
        private System.Windows.Forms.RadioButton w1;
        private System.Windows.Forms.RadioButton d1;
        private System.Windows.Forms.RadioButton h8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox los;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button atwl;
        private System.Windows.Forms.TextBox symbolText;
        private System.Windows.Forms.TextBox output;
        private System.Windows.Forms.Label openL;
        private System.Windows.Forms.Label closeL;
        private System.Windows.Forms.Label dates;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.Label h;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label closeN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label openN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button pv;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label pp;
    }
}

